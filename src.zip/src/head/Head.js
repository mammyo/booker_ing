import React, { Component, Fragment } from 'react';
import { NavLink } from 'react-router-dom';
import { Link } from 'react-router-dom';
import './Head.css';


function Head() {
  const activeStyle = {
    color: 'black'

  };
  return (
    <div className="header">
      <div className="logo"><Link exact to="/">Booker-Ceo</Link></div>

      <div className="menu">
        <Link exact to="/" activeStyle={activeStyle}>홈</Link>
        <Link exact to="/check" activeStyle={activeStyle}>예약확인</Link>
        <Link exact to="/service" activeStyle={activeStyle}>서비스</Link>
      </div>
    </div>
  );

}




export default Head;