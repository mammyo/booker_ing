import React from 'react';
import Usertabs2 from '../module/tabs2/Usertabs2';
import './Service.css';
import CeoRegister from '../Servicelist/CeoRegister';




const Service = () => {

    return (
        <div className='home_body'>
            <div className='service-title'>골라골라</div>
            <div className='home-container-body'>
                <div className='service1-container'>
                    <CeoRegister />
                </div>
            </div>
        </div>
    );
};

export default Service;