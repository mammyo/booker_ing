import React, { Component } from 'react';
import Usertabs from '../module/tabs/Usertabs.js';
import './Home.css';
import { NavLink } from 'react-router-dom';
import UserTabs from '../module/tabs/Usertabs.js';

class Home extends Component {

    state = {
        email:'',
    }

    componentDidMount(){
        console.log(1);
        this.callApi()
            .then(console.log(1))
            .catch(err => console.log(err));
    }

    callApi = async () => {
        const response = await fetch('8080/api/users');
        console.log(2);
        const body = await response.json();
        console.log(body);
        console.log(1);
        this.setState({
            email: body[0].email,
        });
        console.log(this.state.email);
        return body;
    }

    render(){
        return (
            <div className='home_body'>
                <div className='home-title'>배고프다</div>

                <div className='home-container-body'>

                    <div className='home-container'>
                        <div className='inner-title'>
                            예약 리스트
                        </div>
                    </div>
                    <div className='home2-box'>
                        <div className='home2-container'>
                            <div className='inner-title'>
                                일일 예약자
                            </div>
                            <div className='inner-box'>
                                <p>{this.state.email}</p>
                            </div>
                        </div>

                        <div className='home2-container'>
                            <div className='inner-title'>
                                주간 예약자
                            </div>
                            <div className='inner-box'>
                                5명
                            </div>
                        </div>

                        <div className='home2-container'>
                            <div className='inner-title'>
                                월간 예약자
                            </div>
                            <div className='inner-box'>
                                5명
                            </div>
                        </div>

                        <div className='home2-container'>
                            <div className='inner-title'>
                                예약 취소
                            </div>
                            <div className='inner-box'>
                                5명
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
};

export default Home;